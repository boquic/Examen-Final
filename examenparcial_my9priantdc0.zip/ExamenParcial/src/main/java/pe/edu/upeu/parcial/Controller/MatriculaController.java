package pe.edu.upeu.parcial.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import pe.edu.upeu.parcial.Entity.Matricula;
import pe.edu.upeu.parcial.Service.MatriculaService;

@RestController
@RequestMapping("/api/matriculas")
public class MatriculaController {

    @Autowired
    private MatriculaService matriculaService; 

    @GetMapping
    public ResponseEntity<List<Matricula>> readAll() {
        try {
            List<Matricula> matriculas = matriculaService.readAll(); 
            if (matriculas.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
            }
            return new ResponseEntity<>(matriculas, HttpStatus.OK); 
        } catch (Exception e) {
            // Consider logging the exception
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping
    public ResponseEntity<Matricula> crear(@Valid @RequestBody Matricula cat) {
        try {
            Matricula c = matriculaService.create(cat);
            return new ResponseEntity<>(c, HttpStatus.CREATED);
        } catch (Exception e) {
            // Consider logging the exception
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Matricula> getMatriculaId(@PathVariable Long id) {
        try {
            Optional<Matricula> optionalMatricula = matriculaService.read(id);
            if (optionalMatricula.isPresent()) {
                return new ResponseEntity<>(optionalMatricula.get(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            // Consider logging the exception
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delMatricula(@PathVariable Long id) {
        try {
            matriculaService.delete(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            // Consider logging the exception
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateAMatricula(@PathVariable("id") Long id, @Valid @RequestBody Matricula cat) {
        try {
            Optional<Matricula> optionalMatricula = matriculaService.read(id);
            if (optionalMatricula.isPresent()) {
                Matricula updatedMatricula = matriculaService.update(cat);
                return new ResponseEntity<>(updatedMatricula, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            // Consider logging the exception
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
