package pe.edu.upeu.parcial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class ExamenParcialApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenParcialApplication.class, args);
	}

}
