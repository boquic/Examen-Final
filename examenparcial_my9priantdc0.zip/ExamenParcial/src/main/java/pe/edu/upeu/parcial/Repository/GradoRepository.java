package pe.edu.upeu.parcial.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upeu.parcial.Entity.Grado;

public interface GradoRepository extends JpaRepository<Grado, Long>{

}
