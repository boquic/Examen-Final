package pe.edu.upeu.parcial.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upeu.parcial.Entity.Matricula;

public interface MatriculaRepository extends JpaRepository<Matricula, Long>{

}
