package pe.edu.upeu.parcial.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upeu.parcial.Entity.Empleado;

public interface EmpleadoRepository extends JpaRepository<Empleado, Long>{

}
