package pe.edu.upeu.parcial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenParcialApplicationTests {

	@Test
	void contextLoads() {
	}

}
